# Base Products Migration Support 
Base product migration support scripts for WSO2 Identity Server migration from 5.10.0 to 5.11.0 and 
WSO2 API Manager migration from 3.2.0 to 4.0.0.

# How to use the scripts

* These DB scripts can be used to troubleshoot DB issues arise in 
  * WSO2 Identity Server migration from 5.10.0 to 5.11.0 and 
  * Identity component migration during WSO2 API Manager migration from 3.2.0 to 4.0.0.

### WSO2 Identity Server migration from 5.10.0 to 5.11.0

* If you are running the migration tool for WSO2 Identity Server migration from 5.10.0 to 5.11.0 for more than once, 
  you can run scripts given here, before running the WSO2 Identity Server migration tool 
  according to the database you are using. 
  
  (i.e. before following [step 11](https://is.docs.wso2.com/en/5.11.0/setup/migrating-to-5110/#:~:text=Start%20the%20WSO2%20Identity%20Server%205.11.0%20with%20the%20following%20command%20to%20execute%20the%20migration%20client.)
  of [Steps to migrate to 5.11.0](https://is.docs.wso2.com/en/5.11.0/setup/migrating-to-5110/#steps-to-migrate-to-5110))
* Please note that you do not need to run these support scripts before running WSO2 Identity Server migration tool 
  if you are running the  WSO2 Identity Server migration tool against your database for the first time.


### Identity component migration during WSO2 API Manager migration from 3.2.0 to 4.0.0

* You can run scripts provided here according to the database you are using, 
  before running the WSO2 Identity Server migration tool for migrating Identity component of
  WSO2 API Manager during WSO2 API Manager migration from 3.2.0 to 4.0.0.

  (i.e. before following [step 6](https://apim.docs.wso2.com/en/latest/install-and-setup/upgrading-wso2-api-manager/upgrading-from-320-to-400/#:~:text=6.%20Start%20WSO2%20API%20Manager%204.0.0%20as%20follows%20to%20carry%20out%20the%20complete%20Identity%20component%20migration.) 
  of [Step 2 - Upgrade API Manager to 4.0.0](https://apim.docs.wso2.com/en/latest/install-and-setup/upgrading-wso2-api-manager/upgrading-from-320-to-400/#step-2-upgrade-api-manager-to-400))


### Running Base Product Migration Support Scripts

* Base product migration support scripts are available in the 
  `ob-migration-resources/components/com.wso2.openbanking.migration.client/openbanking-migration-resources/base-product-migration-support-scripts`
  directory.
* If your database is \<DB>, the name of the relevant script for your database is in the format
  ```
  Initialize_IS_APIM_migration_to_latest_<DB>.sql
  ```
  For example, if you are using mssql as your database, 
  then you should run the `Initialize_IS_APIM_migration_to_latest_mssql.sql` against your database.
* If you are using **Postgres** database please use **psql** to execute the database script against your database.

