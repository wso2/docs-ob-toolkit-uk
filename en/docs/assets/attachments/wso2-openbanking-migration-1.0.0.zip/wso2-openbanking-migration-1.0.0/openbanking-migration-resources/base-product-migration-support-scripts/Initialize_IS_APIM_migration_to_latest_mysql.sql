SET SQL_SAFE_UPDATES = 0;

DELETE FROM
    openbank_userdb.UM_HYBRID_ROLE
WHERE
    UM_ROLE_NAME = 'admin';

DELETE FROM
    openbank_userdb.UM_ROLE_PERMISSION
WHERE
    UM_ROLE_NAME = 'admin';
   
DELETE FROM
    openbank_userdb.UM_USER
WHERE
    UM_USER_NAME = 'admin';

DELETE FROM
    openbank_apimgtdb.IDN_CONFIG_TYPE
WHERE
    NAME = 'CORS_CONFIGURATION';
    
DELETE FROM
    openbank_apimgtdb.SP_APP
WHERE
    APP_NAME = 'My Account';
    
DELETE FROM
    openbank_apimgtdb.IDN_OAUTH_CONSUMER_APPS
WHERE
    APP_NAME = 'MY_ACCOUNT';

DELETE FROM
    openbank_apimgtdb.IDN_OAUTH_CONSUMER_APPS
WHERE
    APP_NAME = 'My Account';
    
DELETE FROM
    openbank_userdb.UM_HYBRID_ROLE
WHERE
    UM_ROLE_NAME = 'Application/My Account';
    
COMMIT;


SET SQL_SAFE_UPDATES = 1;


DROP PROCEDURE IF EXISTS drop_UM_TENANT_UUID_column_if_exists;

DELIMITER $$
CREATE PROCEDURE drop_UM_TENANT_UUID_column_if_exists()
  BEGIN
    IF (0 < (SELECT count(*) FROM INFORMATION_SCHEMA.Columns 
                WHERE TABLE_SCHEMA = 'openbank_userdb'
                      AND TABLE_NAME = 'UM_TENANT'
                      AND COLUMN_NAME = 'UM_TENANT_UUID'))
    THEN
      ALTER TABLE openbank_userdb.UM_TENANT DROP COLUMN UM_TENANT_UUID;
    END IF;
  END $$
DELIMITER ;

call drop_UM_TENANT_UUID_column_if_exists;


DROP TABLE IF EXISTS openbank_apimgtdb.IDN_CORS_ASSOCIATION;
DROP TABLE IF EXISTS openbank_apimgtdb.IDN_REMOTE_FETCH_REVISIONS;
DROP TABLE IF EXISTS openbank_apimgtdb.IDN_REMOTE_FETCH_CONFIG;

