GRANT CREATE ANY PROCEDURE to openbank_am_configdb;
GRANT CREATE ANY PROCEDURE to openbank_apimgtdb;
GRANT CREATE ANY PROCEDURE to openbank_userdb;

DELETE FROM
    openbank_userdb.UM_HYBRID_ROLE
WHERE
    UM_ROLE_NAME = 'admin';

COMMIT;

DELETE FROM
    openbank_userdb.UM_ROLE_PERMISSION
WHERE
    UM_ROLE_NAME = 'admin';

COMMIT;
   
DELETE FROM
    openbank_userdb.UM_USER
WHERE
    UM_USER_NAME = 'admin';

COMMIT;

DELETE FROM
    openbank_apimgtdb.IDN_CONFIG_TYPE
WHERE
    NAME = 'CORS_CONFIGURATION';
    
COMMIT;
    
DELETE FROM
    openbank_apimgtdb.SP_APP
WHERE
    APP_NAME = 'My Account';

COMMIT;
    
DELETE FROM
    openbank_apimgtdb.IDN_OAUTH_CONSUMER_APPS
WHERE
    APP_NAME = 'MY_ACCOUNT';

DELETE FROM
    openbank_apimgtdb.IDN_OAUTH_CONSUMER_APPS
WHERE
    APP_NAME = 'My Account';

COMMIT;
    
DELETE FROM
    openbank_userdb.UM_HYBRID_ROLE
WHERE
    UM_ROLE_NAME = 'Application/My Account';
    
COMMIT;

ALTER TABLE openbank_userdb.UM_TENANT
  DROP COLUMN UM_TENANT_UUID;

COMMIT;

