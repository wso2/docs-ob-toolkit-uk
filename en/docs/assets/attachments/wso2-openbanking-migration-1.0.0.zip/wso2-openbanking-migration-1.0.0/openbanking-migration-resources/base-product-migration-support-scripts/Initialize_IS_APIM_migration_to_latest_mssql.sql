DELETE FROM
    openbank_userdb.dbo.UM_HYBRID_ROLE
WHERE
    UM_ROLE_NAME = 'admin';

DELETE FROM
    openbank_userdb.dbo.UM_ROLE_PERMISSION
WHERE
    UM_ROLE_NAME = 'admin';
  
DELETE FROM
    openbank_userdb.dbo.UM_USER
WHERE
    UM_USER_NAME = 'admin';

DELETE FROM
    openbank_apimgtdb.dbo.IDN_CONFIG_TYPE
WHERE
    NAME = 'CORS_CONFIGURATION';
    
DELETE FROM
    openbank_apimgtdb.dbo.SP_APP
WHERE
    APP_NAME = 'My Account';
    
DELETE FROM
    openbank_apimgtdb.dbo.IDN_OAUTH_CONSUMER_APPS
WHERE
    APP_NAME = 'MY_ACCOUNT';

DELETE FROM
    openbank_apimgtdb.dbo.IDN_OAUTH_CONSUMER_APPS
WHERE
    APP_NAME = 'My Account';
 
DELETE FROM
    openbank_userdb.dbo.UM_HYBRID_ROLE
WHERE
    UM_ROLE_NAME = 'Application/My Account';
    
    
USE openbank_userdb;

DECLARE @Val1 VARCHAR(50)

select @Val1 = name from dbo.sysobjects where OBJECTPROPERTY(id, N'IsConstraint') = 1 AND name like 'DF__UM_TENANT__UM_TE__%'

IF (@Val1 IS NOT NULL)
BEGIN
    EXECUTE ('ALTER TABLE openbank_userdb.dbo.UM_TENANT DROP CONSTRAINT ' + @Val1)
END


DECLARE @table_name nvarchar(256)
DECLARE @col_name nvarchar(256)
DECLARE @Command  nvarchar(1000)

SET @table_name = 'UM_TENANT'
SET @col_name = N'UM_TENANT_UUID'

SELECT @Command = 'ALTER TABLE ' + @table_name + ' DROP CONSTRAINT ' + d.name
    FROM sys.tables t
    JOIN sys.indexes d ON d.object_id = t.object_id  AND d.type=2 and d.is_unique=1
    JOIN sys.index_columns ic on d.index_id=ic.index_id and ic.object_id=t.object_id
    JOIN sys.columns c on ic.column_id = c.column_id  and c.object_id=t.object_id
    WHERE t.name = @table_name and c.name=@col_name

SELECT @Command

EXEC sp_executesql @Command;

ALTER TABLE openbank_userdb.dbo.UM_TENANT
  DROP COLUMN IF EXISTS UM_TENANT_UUID;
  

DROP TABLE IF EXISTS openbank_apimgtdb.dbo.IDN_CORS_ASSOCIATION;
DROP TABLE IF EXISTS openbank_apimgtdb.dbo.IDN_REMOTE_FETCH_REVISIONS;
DROP TABLE IF EXISTS openbank_apimgtdb.dbo.IDN_REMOTE_FETCH_CONFIG; 

