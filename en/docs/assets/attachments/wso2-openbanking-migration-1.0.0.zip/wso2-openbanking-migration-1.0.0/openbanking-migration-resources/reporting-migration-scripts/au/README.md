# AU - Reporting Data Migration 
Reporting migration scripts for WSO2 Open Banking Accelerator and AU toolkit.

# How to use the scripts

* Shutdown WSO2-OBBI-2.0.0 if it is running.
* Backup your `openbank_ob_reporting_statsdb`, `openbank_ob_reporting_summarizeddb` Databases of your OBBI 2.0.0 instance.
* Open the `openbanking-migration-resources/reporting-migration-scripts/au/configure.properties` file and configure the following.
  * Databases related properties and database names
  * Access token encryption configurations
    * These properties are available in the `<BIServer><Reporting><TokenEncryption>` section of `<WSO2_OB2_IS_SEVER>/repository/conf/finance/open-banking.xml` 
      ``` 
      <BIServer>        
          <Reporting>   
              <TokenEncryption>
                  <Enable>true</Enable>
                  <SecretKey>wso2</SecretKey>
              </TokenEncryption>
          </Reporting>
      </BIServer>
      ```
* Run the migrate.sh file in the `openbanking-migration-resources/reporting-migration-scripts/au`
  directory 
  ```
  ./migrate.sh
  ```
  * This will complete the migration of tables and data related to AU reporting from OB2 to OB3 for **MySQL** database.
  * Please note that, although Oracle migration is not completed from running migrate.sh, Running migrate.sh after updating `configure.properties` file properly is a **MUST** to update placeholders in Oracle db script. 
* For **Oracle** database, please execute `reporting-oracle-2.0.0_to_3.0.0_runtime.sql` script created in `openbanking-migration-resources/reporting-migration-scripts/au` directory against your `openbank_ob_reporting_statsdb`Database.
  * This will migrate tables and data related to AU reporting from OB2 to OB3 for **Oracle** database.

### Note
* Since following tables of OB_REPORTING_DB are not required in OB3, you can drop them if necessary.
  * AUTHENTICATION_RAW_DATA
  * CDS_SESSION_RAW_DATA
  * ACCESS_TOKEN_RAW_DATA
  * APP_REG_RAW_DATA
