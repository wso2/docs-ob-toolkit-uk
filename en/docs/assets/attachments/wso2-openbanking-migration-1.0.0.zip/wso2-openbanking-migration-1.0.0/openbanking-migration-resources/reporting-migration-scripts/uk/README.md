# UK - Reporting Data Migration 
Reporting migration scripts for WSO2 Open Banking Accelerator.

# How to use the scripts

* Shutdown WSO2-OBBI-2.0.0 if it is running.
* Backup your `openbank_ob_reporting_statsdb`, `openbank_ob_reporting_summarizeddb` Databases of your OBBI 2.0.0 instance.
* Execute relevant sql script in `components/com.wso2.openbanking.migration.client/openbanking-migration-resources/reporting-migration-scripts/uk`
  ( Ex: `reporting-<DB_TYPE>-<FROM_VERSION>_to_<TO_VERSION>.sql`) directory against your `openbank_ob_reporting_statsdb`Database. 
* This will migrate tables and data of UK reporting for OB3.