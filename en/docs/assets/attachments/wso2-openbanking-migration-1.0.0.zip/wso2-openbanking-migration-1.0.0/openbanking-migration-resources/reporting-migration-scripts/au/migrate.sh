#!/bin/bash
# ------------------------------------------------------------------------
#
# Copyright (c) 2022, WSO2 Inc. (http://www.wso2.com). All Rights Reserved.
#
# This software is the property of WSO2 Inc. and its suppliers, if any.
# Dissemination of any information or reproduction of any material contained
# herein is strictly forbidden, unless permitted by WSO2 in accordance with
# the WSO2 Commercial License available at http://wso2.com/licenses. For specific
# language governing the permissions and limitations under this license,
# please see the license as well as any agreement you’ve entered into with
# WSO2 governing the purchase of this software and any associated services.
#
# ------------------------------------------------------------------------

# command to execute
# ./migrate.sh

source $(pwd)/configure.properties

# read configure.properties file
if [ "${DB_TYPE}" == "mysql" ]
  then
    DB_SCRIPT=$(pwd)/reporting-mysql-2.0.0_to_3.0.0_runtime.sql
    cp $(pwd)/reporting-mysql-2.0.0_to_3.0.0.sql ${DB_SCRIPT}
elif [ "${DB_TYPE}" == "oracle" ]
  then
    DB_SCRIPT=$(pwd)/reporting-oracle-2.0.0_to_3.0.0_runtime.sql
    cp $(pwd)/reporting-oracle-2.0.0_to_3.0.0.sql ${DB_SCRIPT}
  else
    echo "No migration scripts are available for DB type: ${DB_TYPE}"
fi

update_db_script() {
    sed -i -e 's|DB_OB_REPORTING|'${DB_OB_REPORTING}'|g' ${DB_SCRIPT}
    sed -i -e 's|DB_APIMGT|'${DB_APIMGT}'|g' ${DB_SCRIPT}

    if [ "${ACCESS_TOKEN_ENCRYPTION_ENABLED}" == "true" ]
      then
        sed -i -e 's|ACCESS_TOKEN_ENCRYPTION_KEY|'\'${ACCESS_TOKEN_ENCRYPTION_KEY}\''|g' ${DB_SCRIPT}
      else
        if [ "${DB_TYPE}" == "mysql" ]
          then
            sed -i -e 's|HMACSHA256(ACCESS_TOKEN_ENCRYPTION_KEY, OAT.ACCESS_TOKEN)|OAT.ACCESS_TOKEN|g' ${DB_SCRIPT}
        elif [ "${DB_TYPE}" == "oracle" ]
          then
            sed -i -e 's|lower(dbms_crypto.mac(UTL_I18N.STRING_TO_RAW (OAT.ACCESS_TOKEN, '"'"'AL32UTF8'"'"'), 3, UTL_I18N.STRING_TO_RAW (ACCESS_TOKEN_ENCRYPTION_KEY, '"'"'AL32UTF8'"'"'))) AS ACCESS_TOKEN|OAT.ACCESS_TOKEN|g' ${DB_SCRIPT}
        fi
    fi

}

execute_db_script() {
    if [ "${DB_TYPE}" == "mysql" ]
        then
            if [ "${DB_PASS}" == "" ]
                then
                DB_MYSQL_PASS=""
            else
                DB_MYSQL_PASS="-p${DB_PASS}"
            fi

            mysql -u${DB_USER} ${DB_MYSQL_PASS} -h${DB_HOST} -e "SOURCE ${DB_SCRIPT}";
            rm ${DB_SCRIPT}

    elif [ "${DB_TYPE}" == "oracle" ]
        then
            echo "${DB_SCRIPT} has been updated. Please run the ${DB_SCRIPT} script against your OB_REPORTING_STATS database to migrate data."
    fi
}


update_db_script;

echo -e "\nMigrating AU Reporting Data \n"
echo -e "================================================\n"
execute_db_script;
